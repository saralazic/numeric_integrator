package gui;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JTextField;

import integrator.Keyboard;

import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import javax.swing.AbstractAction;
import java.awt.event.ActionEvent;
import javax.swing.Action;
import javax.swing.ButtonGroup;

import java.awt.event.ActionListener;
import java.awt.GridLayout;
import javax.swing.JRadioButtonMenuItem;


public class NumericIntegration {

	private JFrame frame;
	public JTextField integralInput;
	public JTextField accuracy;
	public JTextField upperBound;
	public JTextField lowerBound;
	private final Action action = new SwingAction();
	
	
	
	private  Keyboard calculator=new Keyboard(this);

	protected static int lowerBoundPosition=0, 
						 upperBoundPosition=1, 
						 accuracyPosition=2 ,
						 integralInputPosition=3;
	
	public int labelPosition;
	private JRadioButton rdbtnTrapeznaFormula;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NumericIntegration window = new NumericIntegration();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NumericIntegration() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(204, 255, 204));
		frame.setBounds(100, 100, 800, 600);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JTextArea textArea = new JTextArea();
		textArea.setBounds(295, 175, 487, 384);
		frame.getContentPane().add(textArea);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(204, 255, 204));
		panel.setBounds(0, 0, 784, 175);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		lowerBound = new JTextField();
		lowerBound.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		lowerBound.setColumns(10);
		lowerBound.setBounds(70, 140, 106, 20);
		panel.add(lowerBound);
		
		integralInput = new JTextField();
		integralInput.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 20));
		integralInput.setBounds(95, 70, 195, 34);
		panel.add(integralInput);
		integralInput.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setIcon(new ImageIcon(NumericIntegration.class.getResource("/resources/photo.png")));
		lblNewLabel.setBounds(15, 11, 91, 150);
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(204, 255, 204));
		panel_1.setBounds(312, 11, 285, 155);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Metoda:");
		lblNewLabel_1.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		lblNewLabel_1.setBounds(10, 11, 52, 20);
		panel_1.add(lblNewLabel_1);
		
		
		
		
		rdbtnTrapeznaFormula = new JRadioButton("Trapezna formula");
		rdbtnTrapeznaFormula.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		rdbtnTrapeznaFormula.setBackground(new Color(204, 255, 204));
		rdbtnTrapeznaFormula.setBounds(68, 7, 139, 29);
		panel_1.add(rdbtnTrapeznaFormula);
		
		JRadioButton rdbtnSimpsonovaFormula = new JRadioButton("Simpsonova formula");
		rdbtnSimpsonovaFormula.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		rdbtnSimpsonovaFormula.setBackground(new Color(204, 255, 204));
		rdbtnSimpsonovaFormula.setBounds(68, 39, 155, 29);
		panel_1.add(rdbtnSimpsonovaFormula);
		
		JRadioButton rdbtnRombergovaMetoda = new JRadioButton("Rombergova metoda");
		rdbtnRombergovaMetoda.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		rdbtnRombergovaMetoda.setBackground(new Color(204, 255, 204));
		rdbtnRombergovaMetoda.setBounds(68, 71, 155, 29);
		panel_1.add(rdbtnRombergovaMetoda);
		
		ButtonGroup bg = new ButtonGroup();
		bg.add(rdbtnRombergovaMetoda);
		bg.add(rdbtnSimpsonovaFormula);
		bg.add(rdbtnTrapeznaFormula);
		
		
		
		
		JLabel lblPreciznostbrojKoraka = new JLabel("Preciznost/Broj koraka:");
		lblPreciznostbrojKoraka.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		lblPreciznostbrojKoraka.setBounds(10, 124, 149, 20);
		panel_1.add(lblPreciznostbrojKoraka);
		
		accuracy = new JTextField();
		accuracy.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		accuracy.setBounds(169, 126, 106, 20);
		panel_1.add(accuracy);
		accuracy.setColumns(10);
		
		upperBound = new JTextField();
		upperBound.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		upperBound.setColumns(10);
		upperBound.setBounds(120, 12, 106, 20);
		panel.add(upperBound);
		
		JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(204, 255, 204));
		panel_2.setBounds(607, 11, 167, 155);
		panel.add(panel_2);
		panel_2.setLayout(null);
		
		JButton btnNewButton = new JButton("Restartuj");
		btnNewButton.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(38, 114, 100, 30);
		panel_2.add(btnNewButton);
		
		JButton btnIzraunaj = new JButton("Izra\u010Dunaj");
		btnIzraunaj.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		btnIzraunaj.setBounds(38, 74, 100, 30);
		panel_2.add(btnIzraunaj);
		
		JPanel calc_panel = new JPanel();
		calc_panel.setBounds(0, 175, 290, 385);
		frame.getContentPane().add(calc_panel);
		
		calc_panel.add(calculator.panel, "West");
		calc_panel.setLayout(new GridLayout(1, 0, 0, 0));
	}
	private class SwingAction extends AbstractAction {
		public SwingAction() {
			putValue(NAME, "SwingAction");
			putValue(SHORT_DESCRIPTION, "Some short description");
		}
		public void actionPerformed(ActionEvent e) {
		}
	}
}
