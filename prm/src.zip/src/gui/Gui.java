package gui;

import integrator.Keyboard;

import java.awt.*;
import java.awt.event.*;

import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextField;

import metode.Romberg;
import metode.Simpson;
import metode.Trapezna;

public class Gui extends JFrame{
	
	protected JTextField integralInput = new JTextField("",6);
	public JTextField upperBound = new JTextField("",6);
	public JTextField lowerBound = new JTextField("",6);
	public JTextField accuracy = new JTextField("",6);
	public JTextField stepCounter=new JTextField("", 6);
	//public JTextField result = new JTextField("",6);
	private Checkbox starto1, starto2, starto3;

	
	public TextArea resultArea = new TextArea();

	
	private JButton start, restart;
	private  Keyboard calculator=new Keyboard(this);
	
	public String s1="", s2=""; 
	
	private static int ROMBERG=0, SIMPSON=1, TRAPEZOIDAL=2;
	private int integrationMethod;
	Panel panel = new Panel();
	
	protected double down, up;

//	public boolean mdg;
//	public boolean mgg; 

	
	protected static int lowerBoundPosition=0, 
						 upperBoundPosition=1, 
						 accuracyPosition=2 ,
						 integralInputPosition=3;
	
	public int labelPosition;
	
	
	
	
	
	public Gui(){
		super("Numericka integracija");
		setBounds(200,200,850,500);
		fillLayaout();
		setVisible(true);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e){
					dispose(); 
			}
		});
		
		down=0; 
		up=0;
	}
	
	
	public static void init(){
		new Gui();
	}
	
	void integral(){
		Panel integral=new Panel();
		integral.setLayout(new GridLayout(1,1));
		ImagePanel imageP = new ImagePanel();
		integral.add(imageP, integral.RIGHT_ALIGNMENT);
		panel.add(integral);
		
		Panel integralData=new Panel();
		integralData.setLayout(new GridLayout(3,1));
		integralData.add(upperBound);
		integralData.add(integralInput);
		integralData.add(lowerBound);
		panel.add(integralData);
	}
	
	void stepsAndAccuracy(){
		Panel dataPanel=new Panel();
		dataPanel.setLayout(new GridLayout(2, 2));
		
		dataPanel.add(new Label("Preciznost:", Label.LEFT));
		dataPanel.add(accuracy);
		
		dataPanel.add(new Label("Broj koraka:", Label.LEFT));
		dataPanel.add(stepCounter);


		panel.add(dataPanel);
	}
	
	void methodChoice(){
		Panel choicePanel=new Panel();
		choicePanel.setLayout(new GridLayout(3, 2));
		
		choicePanel.add(new Label("Metoda integracije:", Label.LEFT));

		CheckboxGroup group = new CheckboxGroup();
		starto1 = new Checkbox("Trapezna formula",group,false);
		starto2 = new Checkbox("Simpsonova formula",group,false);
		starto3 = new Checkbox("Rombergova metoda",group,true);
		
		choicePanel.add(starto1);
		choicePanel.add(new Label(""));

		choicePanel.add(starto2);
		choicePanel.add(new Label(""));

		choicePanel.add(starto3);

		panel.add(choicePanel);
	}
	
	void buttons(){
		Panel buttons=new Panel();
		buttons.setLayout(new GridLayout(2, 1));
		buttons.add(start);
		buttons.add(restart);
		panel.add(buttons);

	}
	
	private class OsluskivacIzbora implements ItemListener{
		@Override
		public void itemStateChanged(ItemEvent dog) {
			Checkbox izvor=(Checkbox)dog.getSource();
			String s=izvor.getLabel();
			switch(s) {
				case "TRAPEZOIDAL formula": integrationMethod=TRAPEZOIDAL; break;
				case "Simpsonova formula": integrationMethod=SIMPSON; break;
				case "Rombergova metoda": integrationMethod=ROMBERG; break;
			}
		}
	}
	
	
	
	@SuppressWarnings("static-access")
	public void PoljaZaUnos(Panel pomocni3) {
/*
		Panel pomocni1 = new Panel();
		Panel pomocni2 = new Panel();
		
		Panel panel1 = new Panel();
		panel1.setLayout(new GridLayout(1,2));

		
		Panel pl1 = new Panel();
		Panel ppl1 = new Panel();
		Panel ppl2 = new Panel();
		Panel IP = new Panel();
		ppl2.setLayout(new GridLayout(1,3));

		Panel ppl3 = new Panel();
		IP.setLayout(new GridLayout(1,2));
		ImagePanel imageP = new ImagePanel();
		IP.add(new Label("Integral: ", Label.RIGHT));
		IP.add(imageP, IP.RIGHT_ALIGNMENT);
	
		
		panel1.add(IP);
	
		
		ppl1.setLayout(new GridLayout(1,2));
		ppl1.add(upperBound);
		ppl1.add(new Label("                                                                                                                                             ", Label.LEFT));
		
		ppl2.add(calculator.setUnos(integralInput));
		ppl3.setLayout(new GridLayout(1,2));
		ppl3.add(lowerBound);
		ppl3.add(new Label("                                                                                                                                              ", Label.LEFT));
		
		pl1.setLayout(new GridLayout(5,1));
		pl1.add(ppl1);
		pl1.add(pomocni1);
		pl1.add(ppl2);
		pl1.add(pomocni2);
		pl1.add(ppl3);
		
		panel1.add(pl1);
		panel.add(panel1);
	
		
		Panel pl2 = new Panel();
		*/
		methodChoice();
		
		
		//Opcija da kad kliknem na TextField unosim tacno tu vrednost
		upperBound.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				calculator.inicijalizacijaG(upperBound.getText()); //enable odgovarajucih dugmica
				//DODAJ
				labelPosition=upperBoundPosition;
			}
		});
		
		lowerBound.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				calculator.inicijalizacijaG(lowerBound.getText()); //enable odgovarajucih dugmica
				//DODAJ
				labelPosition=lowerBoundPosition;
			}
		});
		
		accuracy.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				calculator.inicijalizacijaP(); //enable odgovarajucih dugmica
				//DODAJ
				labelPosition=accuracyPosition;
			}	
		});
		
		integralInput.addMouseListener(new MouseAdapter() {
			public void mouseClicked(MouseEvent e) {
				calculator.inicijalizacija(); //enable odgovarajucih dugmica
				//DODAJ
				labelPosition=integralInputPosition;
			}
		});

	}

	
	public void DugmeZaresult() {
		start = new JButton("Izracunaj");
		start.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Double rez;
				rez=0.0;
				String accuracyPosition=accuracy.getText();
				up=calculator.rGran(upperBound.getText());
				down=calculator.rGran(lowerBound.getText());
				
				switch(integrationMethod) {
					case 0: {
						Romberg r=new Romberg(Double.parseDouble(accuracyPosition), Gui.this);
						if (up>down)
								rez=r.Racunaj(calculator.f, down, up);
						else
								rez=-r.Racunaj(calculator.f, up, down);
					}; break;
						case 1:{
							Simpson r=new Simpson(Double.parseDouble(accuracyPosition), Gui.this);
							if (up>down)
									rez=r.Racunaj(calculator.f, down, up);
							else
									rez=-r.Racunaj(calculator.f, up, down);
						}; break;
						
						case 2:{
							Trapezna tr=new Trapezna(Double.parseDouble(accuracyPosition), Gui.this);
							if (up>down)
								rez=tr.Racunaj(calculator.f, down, up);
						else
								rez=-tr.Racunaj(calculator.f, up, down);
						};
					}
				//result.setText(""+rez);
			
			
			resultArea.setText(s1+"\n\n\n"+s2);
			resultArea.append("\n\nI="+rez);
			
		}
		});
	}
	
	public void RestartDugme() {
		restart = new JButton("Restartuj");
		restart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				
				calculator.reset(); 
				
				//enable dugmica na tastaturi se vraca na pocetne vrednosti
				calculator.inicijalizacija();
			
				upperBound.setText("");
				lowerBound.setText("");
				integralInput.setText("");
				//result.setText("");
				accuracy.setText("");
			}	
		});
	}
		

	private void fillLayaout()
	{

	add(resultArea, "Center");
	
		//panel.setLayout(new GroupLayout(arg0)));
		Color backgroundColor = new Color(254,255,205);
		panel.setBackground(backgroundColor);
		panel.setSize(150, 650);
		add(panel, "North");
		
		integral();
		stepsAndAccuracy();
		methodChoice();
		
		DugmeZaresult();	
		RestartDugme();
		
		buttons();
		/*Panel pomocni3 = new Panel();

		PoljaZaUnos(pomocni3);	
		
		DugmeZaresult();
		
		RestartDugme();
		
		Panel pl3 = new Panel();
		pl3.setBackground(backgroundColor);
		pl3.setLayout(new GridLayout(4, 1));
		Panel pll3 = new Panel();
		pll3.add(start);
		pl3.add(pll3);
		Panel pll2 = new Panel();
		pll2.add(restart);
		pl3.add(pll2);
		pl3.add(pomocni3);
		
		Panel pppl1 = new Panel();
		pppl1.add(new Label("Broj koraka:", Label.LEFT));
		pppl1.add(stepCounter);
		pl3.add(pppl1);
		panel.add(pl3);
*/
		add(calculator.ploca, "West");;
		
	}

	
	
	

	/*
	public void menue(Panel pl) {
		/*Panel pl2=new Panel();
		Panel pomocni5 = new Panel();
		Panel pomocni6 = new Panel();
		Panel pomocni7 = new Panel();
		Panel pomocni8 = new Panel();
		Panel pomocni9=new Panel();
		Panel pomocni10=new Panel();
		
		pomocni6.setLayout(new GridLayout(1, 2));
		pomocni7.setLayout(new GridLayout(1, 2));
		pomocni8.setLayout(new GridLayout(1, 2));
		pomocni5.setLayout(new GridLayout(1, 2));
		
		
		Panel ppomocni5 = new Panel();
		Panel ppomocni6 = new Panel();
		Panel ppomocni7 = new Panel();
		Panel ppomocni8 = new Panel();
		Panel ppomocni9=new Panel();
		Panel ppomocni10=new Panel();
		
		pl2.setLayout(new GridLayout(4, 1));
		
		
		ppomocni7.add(new Label("  accuracy/korak:", Label.LEFT));
		ppomocni8.add(accuracy);
		ppomocni9.add(new Label(" Broj koraka:"), Label.LEFT);
		ppomocni10.add(stepCounter);
		
		pomocni5.add(ppomocni5);
		pomocni6.add(ppomocni6);
		pomocni7.add(ppomocni7);
		pomocni8.add(ppomocni8);
		pomocni9.add(ppomocni9);
		pomocni10.add(ppomocni10);
		
		pomocni5.add(new Label("Metoda integracije:", Label.LEFT));
		CheckboxGroup grupa = new CheckboxGroup();
		starto1 = new Checkbox("TRAPEZOIDAL formula",grupa,false);
		pomocni6.add(starto1);
		starto2 = new Checkbox("Simpsonova formula",grupa,false);
		pomocni7.add(starto2);
		starto3 = new Checkbox("Rombergova metoda",grupa,true);
		pomocni8.add(starto3);
		
		OsluskivacIzbora osluskivac=new OsluskivacIzbora();
		
		starto1.addItemListener(osluskivac);
		starto2.addItemListener(osluskivac);
		starto3.addItemListener(osluskivac);
		
		pl2.add(pomocni5);
		pl2.add(pomocni6);
		
		Panel pl3=new Panel();
		pl3.setLayout(new GridLayout(4,1));
		pl2.add(pomocni7);
		pl2.add(pomocni8);
		pl3.add(pomocni9);
		pl3.add(pomocni10);
		pl.setLayout(new GridLayout(2,1));
		//pl.add(pl3);
		//pl.add(pl2);
		panel.add(pl2);
		
		
	}
	*/
	
	
}

	

