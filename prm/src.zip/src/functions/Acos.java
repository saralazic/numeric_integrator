package functions;

public class Acos extends Function{

	public Acos() {}
	
	public double aprox(double x) {
		return Math.acos(x);
	}
	
}
