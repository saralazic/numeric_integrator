package functions;

public class Tan extends Function{

	public Tan() {}
	
	public double aprox(double x) {
		return Math.tan(x);
	}
}
