package functions;

public class Atan extends Function{
	
	public Atan() {}
	
	public double aprox(double x) {
		return Math.acos(x);
	}

}
