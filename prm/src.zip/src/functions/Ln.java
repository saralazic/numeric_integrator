package functions;

public class Ln extends Function{

	public Ln() {}
	
	public double aprox(double x) {
		return Math.log(x);
	}
}
