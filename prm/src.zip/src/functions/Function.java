package functions;

public abstract class Function {
	
	public Function() {}
	
	public abstract double aprox(double x);
	
	
}
