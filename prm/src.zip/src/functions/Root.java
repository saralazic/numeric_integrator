package functions;

public class Root extends Function{

	public Root() {}
	
	public double aprox(double x) {
		return Math.sqrt(x);
	}
	
}
