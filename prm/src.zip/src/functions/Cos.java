package functions;

public class Cos extends Function{

	public Cos() {}
	

	public double aprox(double x) {
		return Math.cos(x);
	}
	
}
