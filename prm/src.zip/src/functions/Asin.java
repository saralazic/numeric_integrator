package functions;

public class Asin extends Function{

	public Asin() {}
	
	public double aprox(double x) {
		return Math.asin(x);
	}
	
	
}
