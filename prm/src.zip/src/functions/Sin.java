package functions;

public class Sin extends Function{
	
	public Sin() {}
	
	public double aprox(double x) {
		return Math.sin(x);
	}

}
