package functions;

public class E extends Function{
	
	public E() {}
	

	public double aprox(double x) {
		return Math.pow(Math.E, x);
	}

}
