package functions;

public class Log extends Function{
	
	public Log() {}

	public double aprox(double x) {
		return Math.log10(x);
	}
	
}
