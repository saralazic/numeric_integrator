package metode;

import functions.Function;
import gui.Gui;

public class Trapezna {
	
	private double korak;
	private Gui intgr;
	
	public Trapezna(double korak, Gui i) {
		this.korak=korak;
		this.intgr=i;
	}
	
	
	public double Racunaj(Function f, double Dole, double Gore) {
		double d=0;
		
		String s1, s2;
		
		s1="Trapezna formula aproksimira vrednost integrala na sledeći na�?in: \n";
		s1+="T=(h/2)*(f(a)+f(b)+2*∑f(a+i*h0))\n";
		
		s2="";
		s1+="\n\nT(h)=(h/2)*(f0+2*(";
		s2+="T("+korak+")=("+korak/2+")*("+f.aprox(Dole)+"+2*(";
		
		int i;Double fx;
		for(i=1; i<=((int)((Gore-Dole)/korak)-1); i++) {
			if(i>1) { s1+="+"; s2+="+"; }
			s1+="f"+i;
			fx=f.aprox(Dole+i*korak);
			d+=fx;
			s2+=fx;
		}
		s1+=")+f"+(i+1)+")";
		s2+=")+"+f.aprox(Gore)+")";
		
		intgr.s1=s1;
		intgr.s2=s2;
	
	//	System.out.println(((korak/2)*(f.aprox(Dole)+2*d+f.aprox(Gore))));
		
		return ((korak/2)*(f.aprox(Dole)+2*d+f.aprox(Gore)));
		
	
	}
	
}
