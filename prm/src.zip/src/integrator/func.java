package integrator;


//PAZI DA LI TREBA DA ISKOPIRAS LISTU	

public class func {
	
	public static final int BROJ=0, 
							BIN_OP=1, 
							PROM=2,
							UN_OP=3,
							PI=4,
							ZAGR=5;
				
	 
	//zapis funkcije u vidu liste ciji su elementi operandi i operatori
	protected Elem glava;
	protected Elem rep;
	protected Elem pret;
		
	//stek koji koristimo u pretvaranju infiksa u postfiks
	protected Lista stek;
			
	//postfiksni oblik
	protected Lista postfix;
			
	protected boolean un;
	
			public func() {
				glava=rep=pret=null;
				postfix=new Lista();
				un=false;
			}	
			
			public void printfun() {
				Elem tek=glava;
				while (tek!=null) {
					System.out.print(tek.sadrzaj+" ");
					tek=tek.sledeci;
				}
			}
			
			//dodavanje operatora u listu 
			public void dodajOper(String s, boolean b) throws Error {
				//Ako je lista prazna
				if(glava==null) 
					if (b==true) throw new Error();//i ako je binarni, greska je u unosu
					else 
						if (s=="π") 
							glava=rep=new Elem(s, func.PI); //ako je pi, dodajem pi
						else if (s=="(" || s==")")
							glava=rep=new Elem(s, func.ZAGR); //ako je zagrada, dodajem zagradu 
						else {
								un=true;
								glava=rep=new Elem(s, func.UN_OP); //ako je unarni, dodajem unarni
						}
				
				//Ako lista nije prazna, dodajem element na kraj 
				else 
					{
					if (b==true)	 
					{
						rep.sledeci=new Elem(s, func.BIN_OP);
					}
				else {
					if (s=="π") 
						rep.sledeci=new Elem(s, func.PI); //ako je pi, dodajem pi
					else if (s=="(" || s==")")
						rep.sledeci=new Elem(s, func.ZAGR); //ako je zagrada, dodajem zagradu 
					else 
						rep.sledeci=new Elem(s, func.UN_OP); //ako je unarni, dodajem unarni	
				}
					pret=rep;
					rep=rep.sledeci;
			}
			}
			
			
			
			
			//dodavanje cifre (ili u vec postojeci element
			//ili u novi ako je prethodni element operator)
			//u ovoj funkciji se takodje u listu dodaje i promenljiva
			public void dodajCif(String s) {
				if(glava==null) 
					if (s=="x") 
							glava=rep=new Elem(s, func.PROM);
					else 
						glava=rep=new Elem(s, func.BROJ);
				else {
					if (rep.ind==BROJ) rep.sadrzaj+=s;
					else {
						if (s=="x")
							{
								rep.sledeci=new Elem(s, func.PROM);
							}
						else rep.sledeci=new Elem(s, func.BROJ);
						pret=rep;
						rep=rep.sledeci;
					}
				}
			}
			
			
			
			public void dodajEl(Elem e) {
				Elem el=new Elem(e); 
				if(glava==null) glava=rep=el;
				else {
					rep.sledeci=el;
					rep=rep.sledeci;
				}
			}
			
			
			public void uredi() {
				Elem tmp1=glava, tmp2=glava;
				while(tmp2!=null) {
					tmp2=tmp2.sledeci;
					if(tmp1.ind!=BIN_OP && tmp2.ind!=BIN_OP) {
						tmp1.sledeci=new Elem("*", BIN_OP);
						tmp1.sledeci.sledeci=tmp2;
					}
					tmp1=tmp2;
				}
			}
				
			//provera da li je operacija prefiksna
			public boolean pref(String s) {
				if (s=="log" || s=="ln" || s=="e^" || s=="√"
				|| s=="sin" || s=="cos" || s=="tg" || s=="ctg"
				|| s=="asin" || s=="acos" || s=="atan" || s=="acot")
					return true;
				return false;
			}
			
			
			//POPRAVI
			public void in2post() throws Error {
				int rank=0; Elem x;
				stek=new Lista();
				
				TabelaPrioriteta tab=new TabelaPrioriteta();
				Elem next=glava;
				
				while(next!=null) {
					if(next.ind==func.BROJ || next.ind==func.PI ||
							next.ind==func.PROM) { 
						postfix.OUTPUT(next);
						rank++;
					}
					else
						{
							while(!stek.STACK_EMPTY()
									&& (tab.IPR(next)<=tab.SPR(stek.TOP()))) {
								x=stek.POP();
								postfix.OUTPUT(x);
								rank=rank+tab.R(x);
								if(rank<1) throw new Error(); 
							}
							if(next.sadrzaj!=")")
								stek.PUSH(next);
							else x=stek.POP();
						}
					next=next.sledeci;
				}
				while(!stek.STACK_EMPTY()) {
					x=stek.POP();
					postfix.OUTPUT(x);
					rank=rank+tab.R(x);
				}
				
				if(rank!=1) throw new Error();
				
				postfix.printList();
			
			}
			
			
		//racunanje prostih operacija	
		public double calc(double a, double b, String op) {
			double rez=0;
			switch(op) {
				case "+": rez=a+b; break;
				case "-": rez=a-b; break;
				case "*": rez=a*b; break;
				case "/": rez=a/b; break;
				case "^": rez=Math.pow(a, b); break;
			}
			return rez;
		}
		
		
		//izrcunavanje postfiksnog izraza
		public double evalExp(double prom) throws Error {
			Elem x;
			Elem oprnd;
			double rez;
			stek=new Lista();
			
			while(!postfix.END()) {
				x=postfix.INPUT();
				if(x.ind==func.BROJ || x.ind==func.PI
						|| x.ind==func.PROM) stek.PUSH(x);
				else if (x.ind==func.UN_OP)
				{
					oprnd=stek.POP();
					if (oprnd.ind==func.PI) rez=-Math.PI;
					else if(oprnd.ind==func.PROM) rez=-prom;
					else rez=-Double.parseDouble(oprnd.sadrzaj); //kao unarni operand se eventualno moze pojaviti minus
					stek.PUSH(new Elem(Double.toString(rez), func.BROJ));
				}
				else if(x.ind==func.BIN_OP) {
					double o[]=new double[2];
					for(int i=0; i<2; i++) {
						 Elem oper=stek.POP();
						 if (oper.ind==func.BROJ)
							 o[i]=Double.parseDouble(oper.sadrzaj);
						 else if(oper.ind==func.PI)
							 o[i]=Math.PI;
						 else o[i]=prom;
					}
					rez=calc(o[1],o[0], x.sadrzaj);
					stek.PUSH(new Elem(Double.toString(rez), func.BROJ));
					
				}	
			}
			
			Elem el=stek.POP(); 
			if (el==null) throw new Error();
			if(el.ind==func.BROJ)
				rez=Double.parseDouble(el.sadrzaj);
			else throw new Error();
			if(stek.STACK_EMPTY()) return rez;
			else throw new Error();
		}
			
		
		
		
		public void Unarni(Elem p,double x) throws Error{
			Elem priv=p, sled=priv.sledeci;
			
			//ova petlja prolazi kroz celu listu 
			//i eliminise sve unarne operande
			while(priv!=null) {
				if (priv.ind!=func.UN_OP )
				{
					//ako nije unarni operand, samo ide dalje
					//pret=priv;
					priv=priv.sledeci;
					if(sled!=null) sled=sled.sledeci;
				}
				else {//ako je trenutni element unarni operand
					
					Elem tek=priv.sledeci;
					if (sled.ind==func.BIN_OP) throw new Error();
					else {
						func podf=new func(); //podfunkcija 
						//Ako posle unarnog operanda sledi "(", za podfunkciju uzimam sve sto je u zagradi
						if (sled.sadrzaj=="(") {
							int bz;
							bz=1; //brojim zagrade
							//podf.dodajEl(sled);
							tek=sled.sledeci;
							while (tek!=null) {
								if (tek.sadrzaj==")") {
									bz--;
									if (bz<0) throw new Error();
									else if (bz==0) break;
									else podf.dodajEl(tek);
								}
								else{
									if(tek.sadrzaj=="(") bz++;
									podf.dodajEl(tek);
								}
								tek=tek.sledeci;
							}
							if (tek==null && bz!=0) throw new Error(); //ako zagrada nikad nije zatvorena
						}
						else if (sled.ind==func.UN_OP) {
							Unarni(sled,x);
							
							//PROVERI STA JE U ZAGRADI
							podf.dodajEl(priv.sledeci); 
						}
						else 
							podf.dodajEl(sled);
						
					double d=podf.aprox(x);	
					Elem e=new Elem(d+"", func.BROJ);
					if (tek!=null) e.sledeci=tek.sledeci;	
					else e.sledeci=null;
					priv.sledeci=e;
					} //sad je podfunkcija oblika funkcija(broj)
			
					func f;
					/*
					switch(priv.sadrzaj) {
					case "log": f=new Log(); break;
					case "ln":  f=new Ln(); break;
					case "e2": f=new e2(); break;
					case "√": f=new Root(); break;
					case "sin": f=new Sin(); break;
					case "cos": f=new Cos(); break;
					case "tan": f=new Tan(); break;
					case "cot": f=new Cot(); break;
					case "asin": f=new Asin(); break;
					case "acos": f=new Acos(); break;
					case "atan": f=new Atan(); break;
					case "acot": f=new Acot(); break;
					default: f=new fja(); break;
				}
                                        
					double dd=f.aprox(x);
					
					priv.sadrzaj=dd+"";
					priv.ind=fja.BROJ;
			
                                        priv.sledeci=priv.sledeci.sledeci;
                                        */
			}
	}//while(priv!=null)
}//Unarni
			
		public double aprox(double x) throws Error {
			double d;
			if (glava==null) throw new Error();
			//ako ima samo jedan element, vratice njegovu vrednost
			//(ovo je uslov za izlazak iz rekurzije)
			if (glava.equals(rep)) {
				if(glava.ind==func.PI) return Math.PI;
				if (glava.ind==func.BROJ) return Double.parseDouble(glava.sadrzaj);
				else if (glava.ind==func.PROM) return x;
				else throw new Error(); //Greska ako je sam operand ili zagrada
			}
			else {//lista ima vise od jednog elementa
				pret=null;
			if (un==true) Unarni(glava, x);
			in2post();	
				//dodaj opciju da ako lista ima jedan element, vrati tu vrednost i ne zove evalExp
				/*if (glava.sledeci==null) {
					if (glava.equals(rep)) {
						if(glava.ind==funkcija.PI) return Math.PI;
						if (glava.ind==funkcija.BROJ) return Double.parseDouble(glava.sadrzaj);
						else if (glava.ind==funkcija.PROM) return x;
				}
			}*/
				
				d=evalExp(x);
				System.out.println("\n d");
				postfix.rst();
			}
		return d;
		}		
}


