package integrator;

import gui.Gui;

public class Main {
	
	public static double prec=1e-4;
	public static double korak=1e-4;

	public static void main(String[] args)
	{
	
		Gui.init();
		
	}
	
}
