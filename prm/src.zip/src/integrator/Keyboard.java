package integrator;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JButton;
import javax.swing.JTextField;

import functions.Acos;
import functions.Acot;
import functions.Asin;
import functions.Atan;
import functions.Cos;
import functions.Cot;
import functions.E;
import functions.Function;
import functions.Ln;
import functions.Log;
import functions.Root;
import functions.Sin;
import functions.Tan;
import gui.Gui;
import gui.NumericIntegration;


public class Keyboard {
	
	private NumericIntegration gui;
	
	public Panel panel;
	
	private JTextField input;
	public Function integralInput; 
	
	
	private JButton[] digits= new JButton[10];
	private JButton[] operations=new JButton[20];
	private JButton variable;
	private JButton decimal_pt;

	@SuppressWarnings("unused")
	private boolean previousOperation=false; //da li je poslednje uneta operacija
	private int parentheses_cnt=0; //broj otvorenih zagrada
	
	
	
	
	public JTextField setInput(JTextField l) {
		input=l;
		return input;
	}
	
	
	public void reset() {
		integralInput=null;
	}
	
	
	private void ploProm(Panel panel) {
		BrojAkcija osluskivac=new BrojAkcija();
		variable=new JButton("x");
		variable.addActionListener(osluskivac);
		variable.setEnabled(true);
		variable.setVisible(true);
		variable.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
		panel.add(variable);
	}

	private void ploCifre(Panel panel) {
		BrojAkcija osluskivac= new BrojAkcija();
		for(int i=0; i<10; i++) {
			panel.add(digits[i]=new JButton(Integer.toString(i)));
			digits[i].addActionListener(osluskivac);
			digits[i].setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
			digits[i].setEnabled(true);
			//preth=false;
		}	
		decimal_pt=new JButton(".");
		decimal_pt.addActionListener(osluskivac);
		decimal_pt.setEnabled(true);
		decimal_pt.setVisible(true);
		panel.add(decimal_pt);
	}
	
	private void ploOperatori(Panel panel) {
		String[] ozn= {"-","+", "*", "/", "^", 
						"√", "log", "ln", "e^",
						"sin", "cos", "tg", "ctg", 
						"asin", "acos", "atan", "acot", 
						"π", "(", ")"};
		OperAkcija osluskivac=new OperAkcija();
		for(int i=0; i<20; i++) {
			panel.add(operations[i]=new JButton(ozn[i].toString()));
			operations[i].addActionListener(osluskivac);
			operations[i].setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 15));
			if(i<5) operations[i].setEnabled(false);
			else if(i==19) 	operations[i].setEnabled(parentheses_cnt>0);
			else operations[i].setEnabled(true);
		}
		 operations[0].setEnabled(true);
	}

	
	
	//enable dugmica za funkciju
	public void inicijalizacija() {
		for (int i = 0; i < 10; i++)
			digits[i].setEnabled(true);
		for (int i = 0; i < 20; i++) {
			if (i < 5)
				operations[i].setEnabled(false);
			else if (i == 19)
				operations[i].setEnabled(parentheses_cnt > 0);
			else
				operations[i].setEnabled(true);
		}
	}
	
	
	public void inicijalizacijaG(String staro) {
		for(int i=0; i<10; i++) digits[i].setEnabled(true);
		decimal_pt.setEnabled(staro.length()==0);
		for(int i=0; i<20; i++)
			if (i==0 || i==17) operations[i].setEnabled(true);
			else operations[i].setEnabled(false);
	}
	
	//enable dugmica za accuracy 
	public void inicijalizacijaP() {
		for (int i = 0; i < 10; i++)
			digits[i].setEnabled(true);
		decimal_pt.setEnabled(true);
		for (int i = 0; i < 20; i++)
			operations[i].setEnabled(false);
	}
	
		
		
	
	private class OperAkcija implements ActionListener {
		@Override
		public void actionPerformed(ActionEvent dog) {
			String staro;
			String op = dog.getActionCommand();

			switch (gui.labelPosition) {
			case 0: {
				staro = gui.lowerBound.getText();
				staro = staro + op;
				gui.lowerBound.setText(staro);
				if (op == "-") {
	//				gui.mdg = true;
					operations[12].setEnabled(false);
				}

			}
				;
				break;

			case 1: {
				staro = gui.upperBound.getText();
				staro = staro + op;
				gui.upperBound.setText(staro);
				if (op == "-") {
				//	gui.mgg = true;
					operations[12].setEnabled(false);
				}
			}
				;
				break;

			case 3: {
				staro = input.getText();
				switch(op) {
				case "sin": integralInput=new Sin(); break;
				case "cos": integralInput=new Cos(); break;
				case "tan": integralInput=new Tan(); break;
				case "cot": integralInput=new Cot(); break;
				case "asin": integralInput=new Asin(); break;
				case "acos": integralInput=new Acos(); break;
				case "atan": integralInput=new Atan(); break;
				case "acot": integralInput=new Acot(); break;
				case "ln": integralInput=new Ln(); break;
				case "log": integralInput=new Log(); break;
				case "e^": integralInput=new E(); break;
				case "√": integralInput=new Root(); break;
				
				}
				
				
				if (op == "(")
					parentheses_cnt++;
				if (op == ")")
					parentheses_cnt--;

				// enable dugmica za operations
				if (op == "π" || op == ")") {
					for (int i = 0; i < 19; i++)
						operations[i].setEnabled(true);
					operations[19].setEnabled(parentheses_cnt > 0);
				} else
					for (int i = 0; i < 20; i++) {
						if (i < 5)
							operations[i].setEnabled(false);
						else if (i == 19)
							operations[i].setEnabled(false);
						else
							operations[i].setEnabled(true);
					}

				decimal_pt.setEnabled(false);
			
				input.setText(staro + " " + op+" x");
				previousOperation = true;
			};
				break;

			default: {
			}
			}
		}
		
	}
	

	
	
	
	private class BrojAkcija implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent dog) {
			
			String cif=dog.getActionCommand();
			String staro;

			switch(gui.labelPosition) {
			case 0: {
				staro=gui.lowerBound.getText();
				staro=staro+cif;
				gui.lowerBound.setText(staro);
		
			}; break;
			
			case 1:{
				staro=gui.upperBound.getText();
				staro=staro+cif;
				gui.upperBound.setText(staro);
			}; break;
			
			case 2:{
				staro=gui.accuracy.getText();
				staro=staro+cif;
				gui.accuracy.setText(staro);
			}; break;
			
			case 3:{
				staro=input.getText();
				input.setText(staro+cif+" x");
				for(int i=0; i<20; i++) {
					if (cif==".") operations[i].setEnabled(false);
					else operations[i].setEnabled(true);
				}
				operations[19].setEnabled(parentheses_cnt>0);
				if (cif=="." || cif=="x") decimal_pt.setEnabled(false);
				else decimal_pt.setEnabled(true);
			
			
				previousOperation=false;

		
			}; break;
		}
	}
	}
	
	
	
	
	public double rGran(String staro) {
		String s=staro, s1=""; char c;
		double d=0;
		if(!s.contains("π")) d=Double.parseDouble(s);
		else 
		{
			for(int i=0; i<s.length(); i++)
				if ((c=s.charAt(i))!="π".charAt(0)) s1+=c;
			if (s1.length()!=0)
				d=Double.parseDouble(s1)*Math.PI;
			else d=Math.PI;
		}
		return d;
	}
	
	
	

	public Keyboard(NumericIntegration i) {
		
		panel=new Panel();
		panel.setSize(290, 385);
		panel.setLayout(new GridLayout(8,4));
		
		
		ploProm(panel);
		ploCifre(panel);
		ploOperatori(panel);
		
		gui=i;
	}
	
	
	
	
	
	
}
